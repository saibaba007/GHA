# nodejs-hello-world

[![node.js CI](https://github.com/solankiarpan/nodejs-hello-world/actions/workflows/main.yaml/badge.svg)](https://github.com/solankiarpan/nodejs-hello-world/actions/workflows/main.yaml)
